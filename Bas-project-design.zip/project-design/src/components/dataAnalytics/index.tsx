// import * from 'react';


function DataAnalytics() {




    return (

        <>
        <div>DAta Analystics</div>
        </>
    )
}

export default DataAnalytics;