// import * from 'react';


function Licence() {




    return (

        <>
        <div>Licence</div>
        </>
    )
}

export default Licence;