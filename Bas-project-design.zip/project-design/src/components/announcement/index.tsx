// import * from 'react';


function Announcement() {




    return (

        <>
        <div>Announcement</div>
        </>
    )
}

export default Announcement;