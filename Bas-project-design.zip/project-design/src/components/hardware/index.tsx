// import * from 'react';


function Hardware() {




    return (

        <>
        <div>Hardware</div>
        </>
    )
}

export default Hardware;